const  icono= document.querySelectorAll('.iconos');
const fila = document.querySelector('.caro');

icono.forEach((iconos) =>{
    iconos.addEventListener('mouseenter', (e) =>{
        const elmento= e.currentTarget;
        setTimeout(()=>{
            icono.forEach(iconos => iconos.classList.remove('hover'));
            elmento.classList.add('hover');
        },300);
    });
});


fila.addEventListener('mouseleave',()=>{
    icono.forEach(iconos => iconos.classList.remove('hover'));
})